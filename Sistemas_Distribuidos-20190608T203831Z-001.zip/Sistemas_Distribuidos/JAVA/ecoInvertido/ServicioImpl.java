
import java.rmi.*;
import java.rmi.server.*;
import java.io.*;
import java.util.*;

public class ServicioImpl implements IServicio {
		
	public ServicioImpl() throws RemoteException {
		//Es obligatior poner este constructor
    }
    
    public String ecoInvertido(String m) throws RemoteException {
		//Utilizamos SringBuilder porque tiene la funcion reverse
		StringBuilder str = new StringBuilder();
		//Que el contenido de str sea m
		str.append(m);
		//Invertir la cadena
		return(str.reverse().toString());
	}
}
