import java.rmi.*;

public interface IServicio extends Remote {
	public String ecoInvertido(String m) throws RemoteException;
}