import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.*;

public class Cliente {
	private static IServicio servidor = null;
	
	public static void main (String args[]) {
		
		//Seguridad en RMI, las dejamos por defecto
		if (System.getSecurityManager() == null)
			System.setSecurityManager(new SecurityManager());
		
		try {
		//Esto no se quita
		Registry registry = LocateRegistry.getRegistry();
		//Con lookup buscamos un objeto que vamos a obtener para llamar al metodo
		//El identificador debe ser el mismo en el cliente y en el servidor
		//Esto si puede cambiar
		servidor = (IServicio) registry.lookup("objetoRemoto");
		
		//Llamamos al metodo
		//Esto puede llamar
		System.out.println(servidor.ecoInvertido("Hola"));
		}
		catch (RemoteException e) {
			System.err.println("Error de comunicación: " + e.toString());
		}
		catch (Exception e) {
			System.err.println("Excepcion en el Cliente:");
			e.printStackTrace();
		}
	}
}
