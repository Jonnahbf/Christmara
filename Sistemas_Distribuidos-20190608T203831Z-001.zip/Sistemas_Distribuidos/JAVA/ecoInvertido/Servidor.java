import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

public class Servidor {
	public static void main (String args[]) {
				
		if (System.getSecurityManager() == null)
			System.setSecurityManager(new RMISecurityManager());
		
		try {
			ServicioImpl servidor = new ServicioImpl();
			IServicio remote = (IServicio)UnicastRemoteObject.exportObject(servidor, 9900);
			
			LocateRegistry.createRegistry(0);
			
			Registry registry = LocateRegistry.getRegistry();
			registry.rebind("objetoRemoto", remote);
			
			System.out.println("Servidor listo, Enter para terminar");
			System.in.read();
			
			registry.unbind("objetoRemoto");
			UnicastRemoteObject.unexportObject(servidor, true);
		}
		catch (RemoteException e) {
			System.err.println("Error de comunicación: " + e.toString());
		}
		catch (Exception e) {
			System.err.println("Excepcion en el Servidor:");
			e.printStackTrace();
		}
	}
}
