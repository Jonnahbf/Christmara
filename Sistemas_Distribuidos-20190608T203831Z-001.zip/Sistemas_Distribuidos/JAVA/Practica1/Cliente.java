import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.*;
import  java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import  java.io.IOException;

public class Cliente {
	private static Interfaz servidor = null;
	
	public static void main (String args[]) {
		muestraContenido("/proc/loadavg");
	}

	public static void muestraContenido(String archivo) {
		String cadena;
		if (System.getSecurityManager() == null)
			System.setSecurityManager(new SecurityManager());
		
		try {
				Registry registry = LocateRegistry.getRegistry();
				servidor = (Interfaz) registry.lookup("CargaCPU"); //Buscamos el objeto Remoto
				FileReader f = new FileReader(archivo);
				BufferedReader b = new BufferedReader(f);
				cadena = b.readLine();
				servidor.CargaCPU("CPU 1", cadena); //Llamamos a la funcion que calcula la carga del CPU
				b.close();
		}
		catch (RemoteException e) {
			System.err.println("Error de comunicación: " + e.toString());
		}
		catch (Exception e) {
			System.err.println("Excepcion en el Cliente:");
			e.printStackTrace();
		}	
	}
}

		




		