import java.rmi.*;
import java.rmi.server.*;
import java.io.*;
import java.util.*;
import java.util.Random;

public class ServicioImpl implements Interfaz{
	float carga = 0;
		
	public ServicioImpl() throws RemoteException {
    }
    
    public void CargaCPU(String id, String m) throws RemoteException {
	 	String aux;
		float entero;
		String[] parts = m.split(" ");  //Dividimos el String en partes
		for(int i=0; i<3; i++){
			aux = parts[i];
			entero = Float.parseFloat(aux);
			carga = carga + entero;
		}
		carga = carga * 100; //Obtenemos el porcentaje de carga de cada CPU
		
	}

	public int Aleatorio(){
		Random ran = new Random(System.currentTimeMillis());
		int a;
		a = ran.nextInt(10);  //Obtenemos un valor aleatorio entre 0 y 9
		a = a*1000; //Multiplicamos por 1000 para pasar los milisegundos a segundos
		return a;
	}

	public float Carga(){
		return carga;
	 }

}
