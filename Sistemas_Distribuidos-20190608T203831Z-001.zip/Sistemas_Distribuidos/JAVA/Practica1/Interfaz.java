import java.rmi.*;

public interface Interfaz extends Remote {
	public void CargaCPU(String id, String m) throws RemoteException;
	public int Aleatorio() throws RemoteException;
	public float Carga() throws RemoteException;
}