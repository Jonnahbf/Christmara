import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.*;

public class Monitor {
	private static Interfaz service = null;

	public static void main (String args[])  {
		String cadena;
		float a;
		int aleatorio;
		if (System.getSecurityManager() == null)
			System.setSecurityManager(new SecurityManager());
		
		try {
			while(true){
				Registry registry = LocateRegistry.getRegistry();
				service = (Interfaz) registry.lookup("CargaCPU");
				a = service.Carga(); //Llamamos a la funcion que retorna la lista de carga de cada CPU
				System.out.println("La carga del CPU es de: " +a+"%");
				aleatorio = service.Aleatorio(); //Llamamos a la funcion que obtiene un valor aleatorio que sera el tiempo que tardara en llamar al metodo
				Thread.sleep(aleatorio);
			}
		}
		catch (RemoteException e) {
			System.err.println("Error de comunicación: " + e.toString());
		}
		catch (Exception e) {
			System.err.println("Excepcion en el Cliente:");
			e.printStackTrace();
		}	
	}
}



