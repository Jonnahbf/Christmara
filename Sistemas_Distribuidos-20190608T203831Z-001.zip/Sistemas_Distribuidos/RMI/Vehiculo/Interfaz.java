import java.rmi.*;

public interface Interfaz extends Remote {
	public int Calcular(int a, int b, int c) throws RemoteException;
}