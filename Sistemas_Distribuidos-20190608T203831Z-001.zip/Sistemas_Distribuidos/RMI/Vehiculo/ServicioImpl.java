import java.rmi.*;
import java.rmi.server.*;
import java.io.*;
import java.util.*;
import java.util.Random;

public class ServicioImpl implements Interfaz{
		
	public ServicioImpl() throws RemoteException {
    }
    
	public int Calcular(int a, int b, int c)throws RemoteException{
		int aux = a+b+c;
		return aux*20;
	}
 
}
