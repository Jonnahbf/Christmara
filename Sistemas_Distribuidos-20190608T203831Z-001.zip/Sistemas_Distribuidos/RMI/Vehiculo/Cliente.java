import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.*;
import  java.io.IOException;

public class Cliente {
	private static Interfaz servidor = null;
	
	public static void main (String args[]) {

		int result;
		if (System.getSecurityManager() == null)
			System.setSecurityManager(new SecurityManager());
		
		try {
				Registry registry = LocateRegistry.getRegistry();
				servidor = (Interfaz) registry.lookup("Vehiculo"); 
				result = servidor.Calcular(3, 5, 8);
				System.out.println("El pago total del viaje sera: " + result);
		}
		catch (RemoteException e) {
			System.err.println("Error de comunicación: " + e.toString());
		}
		catch (Exception e) {
			System.err.println("Excepcion en el Cliente:");
			e.printStackTrace();
		}	

	}
}

		
