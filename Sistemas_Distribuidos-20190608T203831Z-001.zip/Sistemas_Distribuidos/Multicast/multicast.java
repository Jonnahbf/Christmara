import java.net.*;
import java.io.*;

public class multicast{
	public static void main(String args[]){
		try{
			InetAddress grupo = InetAddress.getByName("225.4.5.6");
			MulticastSocket s = new MulticastSocket(6789);
			s.joinGroup(grupo);
			Hilo me = new Hilo(s);
			byte [] m = args[0].getBytes();
			DatagramPacket mensajeSalida = new DatagramPacket(m, m.length, grupo, 6789);
			s.send(mensajeSalida);
			
		}catch(Exception exc) {
			System.out.println(exc.getMessage());
		}
	}
}


class Hilo extends Thread{
	MulticastSocket multi;
	byte [] bufer = new byte[1024];

	//Constructor
	public Hilo(MulticastSocket s){
		multi = s;
		this.start();
	}	

	public void run(){
		try{
			while(true){
				DatagramPacket mensajeEntrada = new DatagramPacket(bufer, bufer.length);
				multi.receive(mensajeEntrada);
				System.out.println("Recibido:" + new String(mensajeEntrada.getData()));
			}
			
		}catch(Exception exc){System.out.println(exc.getMessage());}
	}
}