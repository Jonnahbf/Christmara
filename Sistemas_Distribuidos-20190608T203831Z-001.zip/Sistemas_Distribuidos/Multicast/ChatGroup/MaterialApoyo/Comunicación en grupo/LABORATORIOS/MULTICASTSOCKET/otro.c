 #include <sys/types.h>   /* include files for IP Sockets */
 #include <sys/socket.h>
 #include <netinet/in.h>
 #include <arpa/inet.h>

 #define BUFSIZE   1024
 #define TTL_VALUE 2
 #define TEST_ADDR "234.5.6.7"
 #define TEST_PORT 3456
 #define LOOPMAX 10
 #define TRUE 1
 #define FALSE 0
 int main(){
   struct sockaddr_in stLocal, stTo, stFrom;
   char achIn[BUFSIZE];
   char achOut[] = "Message number:              ";
   int s;
   struct ip_mreq stMreq;
   int iTmp, i;

   /* get a datagram socket */
   s = socket(AF_INET, SOCK_DGRAM, 0);

   /* avoid EADDRINUSE error on bind() */ 
   iTmp = TRUE;
   setsockopt(s, SOL_SOCKET, SO_REUSEADDR, 
  (char *)&iTmp, sizeof(iTmp));

   /* name the socket */
   stLocal.sin_family =   AF_INET;
   stLocal.sin_addr.s_addr = htonl(INADDR_ANY);
   stLocal.sin_port =     htons(TEST_PORT);
   bind(s, (struct sockaddr*) &stLocal, sizeof(stLocal));

   /* join the multicast group. */
   stMreq.imr_multiaddr.s_addr = inet_addr(TEST_ADDR);
   stMreq.imr_interface.s_addr = INADDR_ANY;
   setsockopt(s, 
      IPPROTO_IP, 
      IP_ADD_MEMBERSHIP, 
      (char *)&stMreq, 
      sizeof(stMreq));

   /* set TTL to traverse up to multiple routers */
   iTmp = TTL_VALUE;
   setsockopt(s, 
      IPPROTO_IP, 
      IP_MULTICAST_TTL, 
      (char *)&iTmp, 
      sizeof(iTmp));

   /* disable loopback */
   iTmp = FALSE;
   setsockopt(s, 
      IPPROTO_IP, 
      IP_MULTICAST_LOOP, 
      (char *)&iTmp, 
      sizeof(iTmp));

   /* assign our destination address */
   stTo.sin_family =      AF_INET;
   stTo.sin_addr.s_addr = inet_addr(TEST_ADDR);
   stTo.sin_port =        htons(TEST_PORT);

   for (i=0;i<LOOPMAX;i++) {
     int addr_size = sizeof(struct sockaddr_in);
     static iCounter = 1;
     int i;

     /* send to the multicast address */
     /*itoa(iCounter++, &achOut[16], 10);*/
     i = sendto(s, achOut, sizeof(achOut), 
       0,(struct sockaddr*)&stTo, addr_size);
     if (i < 0) {
 perror("sendto() failed\n");
       exit(1);
     }

     i = recvfrom(s, achIn, BUFSIZE, 0,
       (struct sockaddr*)&stFrom, &addr_size);
     if (i < 0) {
       perror("recvfrom() failed\n");
       exit(1);
     }
     printf("From host:%s port:%d, %s\n",
       inet_ntoa(stFrom.sin_addr), 
       ntohs(stFrom.sin_port), achIn);
   }
 }
