 #include <sys/types.h>   
 #include <sys/socket.h>
 #include <netinet/in.h>
 #include <arpa/inet.h>

 #define BUFSIZE   1024
 #define TTL_VALUE 2
 #define TEST_ADDR "234.5.6.7"
 #define TEST_PORT 3456
 #define LOOPMAX 10
 #define TRUE 1
 #define FALSE 0

 int main(){
   struct sockaddr_in stLocal, stFrom;
   char achIn[BUFSIZE];
   int s;
   struct ip_mreq stMreq;
   int iTmp, i;

   /* obtener un datagram socket */
   s = socket(AF_INET, SOCK_DGRAM, 0);

   /* evitar error EADDRINUSE  en bind() */ 
   iTmp = TRUE;
   setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *)&iTmp, sizeof(iTmp));

   /* ponerle nombre al socket */
   stLocal.sin_family =   AF_INET;
   stLocal.sin_addr.s_addr = htonl(INADDR_ANY);
   stLocal.sin_port =     htons(TEST_PORT);
   bind(s, (struct sockaddr*) &stLocal, sizeof(stLocal));

   /* agregar a un grupo multicast. */
   stMreq.imr_multiaddr.s_addr = inet_addr(TEST_ADDR);
   stMreq.imr_interface.s_addr = INADDR_ANY;
   setsockopt(s, 
      IPPROTO_IP, 
      IP_ADD_MEMBERSHIP, 
      (char *)&stMreq, 
      sizeof(stMreq));

   for (i=0;i<LOOPMAX;i++) {
     int addr_size = sizeof(struct sockaddr_in);
     static iCounter = 1;
     int i;

     i = recvfrom(s, achIn, BUFSIZE, 0,(struct sockaddr*)&stFrom, &addr_size);
     if (i < 0) {
       perror("recvfrom() fallo!\n");
       exit(1);
     }
     printf("Desde el host:%s puerta:%d, %s\n",
       inet_ntoa(stFrom.sin_addr), 
       ntohs(stFrom.sin_port), achIn);
   }
 }
