#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

extern int errno;
char bufer[256];

main(argc,argv)
int argc;
char *argv[];
{
        struct  sockaddr_in server;
        int x, adrl, sock, conexion;
/********************************************************************/
        sock= socket(AF_INET, SOCK_STREAM, 0);
        if (sock < 0) {
                perror ("no se puede crear socket");
                exit (1);
        }
/********************************************************************/
        bzero(&server, sizeof(server));
        server.sin_family = AF_INET;
        server.sin_addr.s_addr = INADDR_ANY;
        server.sin_port = htons(atoi(argv[1]));
        x = bind(sock, &server, sizeof(server));
        if (x<0){
                close(sock);
                perror("no se puede hacer bind del socket");
                exit(1);
        }
/********************************************************************/
        if (listen(sock, 5) < 0) {
                perror ("no listen");
                exit (1);
        }
/********************************************************************/
        adrl = sizeof (struct sockaddr_in);
        while(1){
                conexion = accept(sock, &server, &adrl);
                printf("Llama el cliente que esta en el host con IP: %s\n",inet_ntoa(server.sin_addr));
                read(conexion,bufer,sizeof(bufer));
                printf("%s",bufer);
                sprintf(bufer,"soy el servidor\n");
                write(conexion,bufer,strlen(bufer)+1);
                printf("cerro la conexion\n");
                close(conexion);
        }
}

