import java.awt.*;
import java.io.*;
import java.net.*;
import java.lang.*;
import java.applet.*;
import java.security.*;
public class prueba {
    public static  void main(String[] args) {
        System.out.println("hola");
	KeyPairGenerator k = null;
	try {
		k = KeyPairGenerator.getInstance("DSA");
		k.initialize(1024, new SecureRandom());
		KeyPair par = k.generateKeyPair();
		Signature dsa = Signature.getInstance("SHA/DSA");
		PrivateKey priv = par.getPrivate();
		dsa.initSign(priv);
	} catch (Exception e){System.out.println("error ");}
    }
}
