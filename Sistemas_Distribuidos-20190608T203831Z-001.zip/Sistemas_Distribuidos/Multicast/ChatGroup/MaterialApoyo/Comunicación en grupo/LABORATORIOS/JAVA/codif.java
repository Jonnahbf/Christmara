import java.io.*;
import java.net.*;
import java.security.*;
class codif {
    public static void main(String[] args) {
        /* Generaci�n y verificaci�n de firmas DSA  */
        Socket echoSocket = null;
        try {
            /* generaci�n de un par */
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("DSA");
            keyGen.initialize(1024, new SecureRandom());
            KeyPair pair = keyGen.generateKeyPair();
            /* Creaci�n de un objeto de Firmas */
            Signature dsa = Signature.getInstance("SHA/DSA");
            /* inicializaci�n del objeto de Firmas */
            PrivateKey priv = pair.getPrivate();
            PublicKey pub = pair.getPublic();
            dsa.initSign(priv);
            /* Actualizaci�n y firma datos */
            FileInputStream fis = new FileInputStream(args[0]);
            byte b;
            while (fis.available() != 0) {
                b = (byte) fis.read();
                dsa.update(b);
                };
            fis.close();
            /* Todos los datos se han leido, se firman */
            byte[] sig = dsa.sign();
        //    String str = "esta es la firma";

            /* Guardar la firma a un archivo */
            echoSocket = new Socket("lsw4.inf.udec.cl", 20000);
            ObjectOutputStream out= new ObjectOutputStream(echoSocket.getOutputStream());
            out.writeObject(pub);
            out.writeObject(sig); //str);

        } catch (Exception e) {
            System.err.println("Caught exception " + e.toString());
        }
    }
}
