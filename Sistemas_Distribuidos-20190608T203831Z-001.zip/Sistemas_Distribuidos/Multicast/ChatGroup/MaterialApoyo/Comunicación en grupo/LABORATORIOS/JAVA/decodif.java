import java.io.*;
import java.security.*;
import java.net.*;
class decodif {
    public static void main(String[] args) {
         ServerSocket serverSocket = null;
         try {
              serverSocket = new ServerSocket(20000);

              Socket clientSocket = null;
             
                   clientSocket = serverSocket.accept();
                       
        /* Generaci�n y verificaci�n de firmas DSA  */
        
        
            Signature dsa = Signature.getInstance("SHA/DSA");
            FileInputStream fis = new FileInputStream(args[0]);
            byte b;

            ObjectInputStream in= new ObjectInputStream(clientSocket.getInputStream());
            PublicKey pub;
            pub = (PublicKey)in.readObject();
            byte[] sig = new byte[4096];
            sig = (byte[])in.readObject();
      //      String str = (String)in.readObject();
       //     System.out.println(str);
            /* Verificaci�n de la firma */
            /* Inicializaci�n del Objeto de Firmas para verificaci�n */
            dsa.initVerify(pub);
            /* Actualizar y verificar datos */
            fis = new FileInputStream(args[0]);
            while (fis.available() != 0) {
                b = (byte) fis.read();
                dsa.update(b);
                };
            fis.close();
            boolean verifies = dsa.verify(sig);
            System.out.println("signature verifies: " + verifies);
        }
         catch (IOException e) {
           System.err.println("No se puede escuchar en puerto:20000.");
                          System.exit(1);
                      }
		 catch (Exception e) {
            System.err.println("Caught exception " + e.toString());
        }

         }
    }

