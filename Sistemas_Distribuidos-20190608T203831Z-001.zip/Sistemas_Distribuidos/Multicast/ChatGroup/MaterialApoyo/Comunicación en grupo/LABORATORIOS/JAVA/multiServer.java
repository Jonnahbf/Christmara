import java.io.*;
import java.net.*;
import java.util.*;

public class multiServer {
    public static void main(String[] args) throws IOException {


	byte[] buf = new byte[256];
	DatagramPacket packet = new DatagramPacket(buf, buf.length);
        MulticastSocket socket = new MulticastSocket(4445);
	socket.joinGroup(InetAddress.getByeName(args[0]));

	socket.receive(packet);
	String recibido = new String(packet.getData(),0);

	System.out.println("llego paquete: " + recibido);

	InetAddress address = packet.getAddress();
	int port = packet.getPort();
	packet = new DatagramPacket(buf, buf.length, address, port);
	socket.send(packet);


	socket.close();
    }
}
