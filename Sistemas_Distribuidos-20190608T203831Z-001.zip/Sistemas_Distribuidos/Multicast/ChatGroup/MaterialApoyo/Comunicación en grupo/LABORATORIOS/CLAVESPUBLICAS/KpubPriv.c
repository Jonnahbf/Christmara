/*
arg1: el entero a encriptar/desencriptar
arg2: e � d
arg3: n
*/
unsigned long potenciamodn(x, y, n)
unsigned long x, y, n;
{
  unsigned long resultado, potencia2, aux_y;
  int i;
  resultado=1; potencia2=x, aux_y=y;
  while (aux_y) {
    if (aux_y&1) resultado = (resultado * potencia2)%n;
    aux_y>>=1;
    potencia2= (potencia2*potencia2)%n;
  }
  return(resultado);
} 
main(argc, argv)
int argc;
char * argv[];
{
unsigned long P, C, x, n;
	C=atoi(argv[1]);
	x=atoi(argv[2]);
	n=atoi(argv[3]);
	P= potenciamodn(C, x, n);	
	printf("%d\t%d\n",C,P);
}
