import java.net.*;
import java.io.*;

public class sendingSocket
{
	public static void main(String args[])
	{
            //5000
            int puerto = 0;
            //225.4.5.6
            String dirMulticast = "";
            InetAddress grupo = null;
            byte buffer[] = new byte[1024];
            MulticastSocket mcs = null;
            DatagramPacket dp = null;
            String mensaje = "";
            
            System.out.print("Ingrese la dirección IP de multicast a la que seran enviados los datos: ");
            dirMulticast = Leer.dato();
            
            System.out.print("Ingrese el puerto al que seran enviados los datos: ");
            puerto = Leer.datoInt();
            
            System.out.print("Ingrese el mensaje a enviar al grupo: ");
            mensaje = Leer.dato();
            
            try
            {
                grupo = InetAddress.getByName(dirMulticast);
                
                mcs = new MulticastSocket();
                //mcs = new MulticastSocket(puerto);
                //mcs.joinGroup(grupo);
                
                buffer = mensaje.getBytes();
                dp = new DatagramPacket(buffer, buffer.length, grupo, puerto);
                mcs.send(dp);
            }
            catch(UnknownHostException uhe)
            {
                System.out.println("Excepción: " + uhe.getMessage());
            }
            catch(SocketException se)
            {
                System.out.println("Excepción: " + se.getMessage());
            }
            catch(IOException ioe)
            {
                System.out.println("Excepción: " + ioe.getMessage());
            }
            finally
            {
                if(mcs != null)
                    mcs.close();
            }
	}
}