import java.net.*;
import java.io.*;

public class receivingSocket
{
	public static void main(String args[])
	{
            //5000
            int puerto = 0;
            //225.4.5.6
            String dirMulticast = "";
            InetAddress grupo = null;
            byte buffer[] = new byte[1024];
            MulticastSocket mcs = null;
            DatagramPacket dp = null;
            
            System.out.print("Ingrese la dirección IP de multicast asociada al grupo: ");
            dirMulticast = Leer.dato();
            
            System.out.print("Ingrese el puerto de escucha asociado al grupo multicast: ");
            puerto = Leer.datoInt();
            
            try
            {
                grupo = InetAddress.getByName(dirMulticast);
                
                mcs = new MulticastSocket(puerto);
                mcs.joinGroup(grupo);
                
                dp = new DatagramPacket(buffer, buffer.length);
                mcs.receive(dp);
                
                System.out.println("Mensaje recibido de: " + dp.getAddress().toString() + ":" + dp.getPort());
                System.out.println("Mensaje con longitud: " + dp.getLength());
                //System.out.println("Contenido del mensaje: " + new String(dp.getData(), 0, dp.getLength()));
                System.out.println();
            }
            catch(UnknownHostException uhe)
            {
                System.out.println("Excepción: " + uhe.getMessage());
            }
            catch(SocketException se)
            {
                System.out.println("Excepción: " + se.getMessage());
            }
            catch(IOException ioe)
            {
                System.out.println("Excepción: " + ioe.getMessage());
            }
            finally
            {
                if(mcs != null)
                {
                    try
                    {
                        mcs.leaveGroup(grupo);
                    }
                    catch(IOException ioe)
                    {
                        System.out.println("Excepción: " + ioe.getMessage());
                    }
                    
                    mcs.close();
                }
            }
	}
}
