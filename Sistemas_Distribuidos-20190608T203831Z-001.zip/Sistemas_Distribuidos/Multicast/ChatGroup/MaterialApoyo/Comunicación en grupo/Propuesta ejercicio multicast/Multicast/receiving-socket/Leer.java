import java.io.*;

public class Leer
{
	public static String dato()
	{
		String sdato = "";
		
		try
		{
			// Definir un flujo de caracteres de entrada: flujoE
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader flujoE = new BufferedReader(isr);
			
			// Leer. La entrada finaliza al pulsar la tecla Entrar
			sdato = flujoE.readLine();
		}
		catch(IOException e)
		{
			System.err.println("Error: " + e.getMessage());
		}
		
		// Devolver el dato tecleado
		return sdato;
	}
	
	public static short datoShort()
	{
		try
		{
			return Short.parseShort(dato());
		}
		catch(NumberFormatException e)
		{
			// Valor mas pequeno
			return Short.MIN_VALUE;
		}
	}
	
	public static int datoInt()
	{
		try
		{
			return Integer.parseInt(dato());
		}
		catch(NumberFormatException e)
		{
			// Valor mas pequeno
			return Integer.MIN_VALUE;
		}
	}
	
	public static long datoLong()
	{
		try
		{
			return Long.parseLong(dato());
		}
		catch(NumberFormatException e)
		{
			// Valor mas pequeno
			return Long.MIN_VALUE;
		}
	}
	
	public static float datoFloat()
	{
		try
		{
			return Float.parseFloat(dato());
		}
		catch(NumberFormatException e)
		{
			// No es un numero; valor float
			return Float.NaN;
		}
	}
	
	public static double datoDouble()
	{
		try
		{
			return Double.parseDouble(dato());
		}
		catch(NumberFormatException e)
		{
			// No es un numero; valor double
			return Double.NaN;
		}
	}
}
