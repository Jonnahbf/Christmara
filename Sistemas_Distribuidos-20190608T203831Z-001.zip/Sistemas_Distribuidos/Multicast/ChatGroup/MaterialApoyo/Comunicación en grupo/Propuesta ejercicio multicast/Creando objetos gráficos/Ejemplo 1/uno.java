public class uno { 
              public static void main(String[ ] arg){ 
                      Pizarra p = new Pizarra(); 
              }  
      } 
