import java.awt.*;
import java.awt.event.*;
import java.util.*; 
import javax.swing.*;
public class Pizarra extends Frame implements	MouseListener,
						MouseMotionListener,
						ActionListener,
						WindowListener { 
	Graphics g;
	Button b;
	Vector v; 
	Polygon p;
	Color c;
	Pizarra(){  
		this.setSize(400,500); 
		this.setVisible(true);
		this.setLayout(null);
		this.addMouseListener(this); 
		this.addMouseMotionListener(this);
		this.addWindowListener(this);
		b = new Button("Color");
		b.setLocation(10,20);
		b.setSize(40,20);
		b.addActionListener(this);
		this.add(b); 
		g = this.getGraphics();
		v = new Vector();
	} 

	public void mousePressed(MouseEvent e){ 
		int x=e.getX(); int y=e.getY();
		p = new Polygon();
		p.addPoint(x, y);
	} 
	public void mouseReleased(MouseEvent e){
		v.add(p);
	} 
	public void mouseClicked(MouseEvent e){;} 
	public void mouseEntered(MouseEvent e){;} 
	public void mouseExited(MouseEvent e){;} 

	public void mouseDragged(MouseEvent e){
		int x=e.getX(); int y=e.getY();
		p.addPoint(x, y);
		g.setColor(c);
		g.drawPolyline(p.xpoints, p.ypoints, p.npoints);
	} 
	public void mouseMoved(MouseEvent e){;} 

        public void actionPerformed(ActionEvent e) { 
                   Component  boton = (Component)e.getSource(); 
                    if(boton==b){ 
			c = JColorChooser.showDialog(this,"Elegir color",Color.blue); 
                   return ; 
                   } 
              } 

	public void windowOpened(WindowEvent e) {;}
	public void windowClosing(WindowEvent e) { 
			this.dispose();
			System.exit(1);
	}
	public void windowClosed(WindowEvent e) {;}
	public void windowIconified(WindowEvent e) {;}
	public void windowDeiconified(WindowEvent e) {;}
	public void windowActivated(WindowEvent e) {;}
	public void windowDeactivated(WindowEvent e) {;}
	public void paint(Graphics g){
		Polygon q;  
		if (v != null)
		for(int i= 0; i<v.size();i++){
			q = (Polygon)v.elementAt(i);
			g.drawPolyline(q.xpoints, q.ypoints, q.npoints);
		}
	} 
} 

