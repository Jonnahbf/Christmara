import java.awt.*;
import java.awt.event.*; 
public class Pizarra extends Frame implements	MouseListener,
						MouseMotionListener { 
	Graphics g;
	Button b; 
	Pizarra(){ 
		this.setSize(400,500); 
		this.setVisible(true);
		this.setLayout(null);
		this.addMouseListener(this); 
		this.addMouseMotionListener(this); 
		b = new Button("boton");
		b.setLocation(50,50);
		b.setSize(40,20);
		this.add(b);
		g = this.getGraphics(); 
	} 

	public void mousePressed(MouseEvent e){;} 
	public void mouseReleased(MouseEvent e){;} 
	public void mouseClicked(MouseEvent e){
		int x=e.getX(); int y=e.getY();
		System.out.println("x: " + x + " y: " + y);
		g.setColor(Color.red);
		g.drawRect(x, y, 100, 100);
		b.setLocation(x,y); 		
	} 
	public void mouseEntered(MouseEvent e){;} 
	public void mouseExited(MouseEvent e){;} 

	public void mouseDragged(MouseEvent e){
		int x=e.getX(); int y=e.getY();
		b.setLocation(x,y);
	} 
	public void mouseMoved(MouseEvent e){;} 

	public void paint(Graphics g){  
		g.drawRect(100, 100, 200, 200); 
	} 
} 
