import java.net.*;
import java.io.*;

public class frmmulticast extends javax.swing.JFrame
{
    public frmmulticast()
    {
        initComponents();

        try
        {
            puerto = 60500;
            dirMulticast = "225.4.5.6";
            grupo = InetAddress.getByName(dirMulticast);
            mcs = new MulticastSocket(puerto);
            mcs.joinGroup(grupo);
        }
        catch(UnknownHostException uhe)
        {
            System.out.println("Método Aplicacion()");
            System.out.println("Excepción UnknownHostException capturada: " + uhe.getMessage());
        }
        catch(SocketException se)
        {
            System.out.println("Método Aplicacion()");
            System.out.println("Excepción SocketException capturada: " + se.getMessage());
        }
        catch(IOException ioe)
        {
            System.out.println("Método Aplicacion()");
            System.out.println("Excepción IOException capturada: " + ioe.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setText("Mensaje");

        jButton1.setText("Enviar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(142, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(116, 116, 116))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        try
        {
            if(mcs != null)
            {
                mcs.leaveGroup(grupo);

                mcs.close();
            }
        }
        catch(IOException ioe)
        {
            System.out.println("Método Aplicacion()");
            System.out.println("Excepción IOException capturada: " + ioe.getMessage());
        }
    }//GEN-LAST:event_formWindowClosing

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if(jTextField1.getText().length() == 0)
            return;

        enviarDatagrama(jTextField1.getText());
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmmulticast().setVisible(true);
            }
        });
    }

    private void enviarDatagrama(String str)
    {
        DatagramPacket dp = null;
        byte buffer[] = null;
        buffer = str.getBytes();

        try
        {
            dp = new DatagramPacket(buffer, buffer.length, grupo, puerto);
            mcs.send(dp);
            System.out.println("-----------------enviarDatagrama()-----------------");
            System.out.println("Se ha enviado un mensaje a: " + dp.getAddress().toString() + ":" + dp.getPort());
            System.out.println("La longitud del mensaje es de: " + dp.getLength());
            System.out.println("----------------------------------------------------");
        }
        catch (IOException ioe)
        {
            System.out.println("Método enviarDatagrama(byte[] bytes)");
            System.out.println("Excepción IOException capturada: " + ioe.getMessage());
        }
    }

    // Variables asociadas a la comunicación
    private int puerto = 0;
    private String dirMulticast = "";
    private InetAddress grupo = null;
    private MulticastSocket mcs = null;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables

}
