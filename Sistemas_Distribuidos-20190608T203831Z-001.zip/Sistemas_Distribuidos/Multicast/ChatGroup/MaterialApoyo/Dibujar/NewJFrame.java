import java.awt.*;
import javax.swing.*;
import java.util.*;

public class NewJFrame extends javax.swing.JFrame {
    
    public NewJFrame() {
        initComponents();
        this.setSize(400,500);
        this.setLayout(null);
        g = this.getGraphics();
        v = new Vector();
        c = Color.BLACK;
    }
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                formMouseReleased(evt);
            }
        });
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>                        

    private void formMousePressed(java.awt.event.MouseEvent evt) {                                  
        int x=evt.getX(); int y=evt.getY();
		p = new Polygon();
		p.addPoint(x, y);
    }                                 

    private void formMouseReleased(java.awt.event.MouseEvent evt) {                                   
        v.add(p);
    }                                  

    private void formMouseDragged(java.awt.event.MouseEvent evt) {                                  
        int x=evt.getX(); int y=evt.getY();
		p.addPoint(x, y);
		g.setColor(c);
		g.drawPolyline(p.xpoints, p.ypoints, p.npoints);
    }                                 
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }
    
    @Override
    public void paint(Graphics g){
		Polygon q;  
		if (v != null)
		for(int i= 0; i<v.size();i++){
			q = (Polygon)v.elementAt(i);
			g.drawPolyline(q.xpoints, q.ypoints, q.npoints);
		}
	}
    
    Graphics g;
    Vector v;
    Polygon p;
    Color c;
    
    // Variables declaration - do not modify                     
    // End of variables declaration   
}
