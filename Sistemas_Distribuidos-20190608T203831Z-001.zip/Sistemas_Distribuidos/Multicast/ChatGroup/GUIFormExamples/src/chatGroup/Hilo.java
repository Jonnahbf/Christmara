/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package chatGroup;

import java.net.DatagramPacket;
import java.net.MulticastSocket;
import javax.swing.*;

/**
 *
 * @author jonathan
 */
public class Hilo extends Thread{
        MulticastSocket s;
        JTextArea mensajes;
	byte [] bufer = new byte[1024];

	//Constructor
	public Hilo(MulticastSocket m, JTextArea msj){
                s = m;
                mensajes = msj;
		this.start();
	}	

	public void run(){
            try{
		while(true){
                    DatagramPacket mensajeEntrada = new DatagramPacket(bufer, bufer.length);
                    s.receive(mensajeEntrada);
                    String contend = new String(mensajeEntrada.getData());
                    contend+="\0";
                     if(this.mensajes.getText().trim().length() == 0)
                         this.mensajes.setText(this.mensajes.getText() + contend.trim());
                    else
                         this.mensajes.setText(this.mensajes.getText() + "\n"+ contend.trim());
		}
            }catch(Exception exc){System.out.println(exc.getMessage());}
	}
}
