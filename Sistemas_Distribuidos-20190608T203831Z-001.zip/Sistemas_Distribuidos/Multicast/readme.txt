Unicast = comunicacion 1 a 1

Broadcast = Envia un mensaje al ultimo valor de la red (la ultima ip), se entrega el mensaje a todos los 
dispositivos de la red.

Multicast = Se crea un grupo de usuarios de la red con los que me quiero comunicar y se envia un msj
a la ip del grupo creado.

La direccion ip de multicast correspopnde a la clase D, y todos los que quieran formar parte del grupo tienen
que unirse al grupo.

Se necesitan 2 direcciones ip, una multicast para poderse comunicar con los usuarios que son partes
del grupo y otra unicast para poderse conectar uno a uno.

No hay diferencia entre cliente y servidor, es un unico programa

Innetadress especificamos la direccion ip del grupo multicast.

joinGroup = Registra el sistema (ordenador) dentro del grupo

leaveGroup = Desvincula el programa del grupo.

Traer instalado NetBeans