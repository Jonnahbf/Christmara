import java.net.*;
import java.io.*;

public class cliente {
	public static void main(String args[]) {
		try {
			DatagramSocket s = new DatagramSocket();
			InetAddress h = InetAddress.getByName(args[0]);
			int puerto = 6789;
			DatagramPacket t;
			//s.send(p);
			FileInputStream inputStream = new FileInputStream("asaber.txt");
			byte [] m = new byte[1024];
			int nRead = 0;
			while ((nRead = inputStream.read(m)) != -1) {
				t = new DatagramPacket(m, m.length, h, puerto);
				s.send(t);
				System.out.println(nRead);
			} 
			byte[]  a = "Jonathan".getBytes();
			t = new DatagramPacket(a, a.length, h, puerto);
			inputStream.close();
		}
		catch(Exception exc) {
			System.out.println(exc.getMessage());
		}
	}
}