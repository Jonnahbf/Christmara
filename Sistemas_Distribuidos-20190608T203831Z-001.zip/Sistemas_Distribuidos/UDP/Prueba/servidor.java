import java.net.*;
import java.io.*;

public class servidor {
	public static void main(String args[]) {
		
		try {
			DatagramSocket s = new DatagramSocket(6789);
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("jonna.txt"));
			byte [] bu = new byte[1024];
			int  a = 0;
			while(true) {
				while(a == 0){
					DatagramPacket dp = new DatagramPacket(bu, bu.length);
					s.receive(dp);
					String str = new String(new String(dp.getData(), 0, dp.getLength())); //dp es el DatagramPacket
					if(str.equals("Jonathan")) a = 1;
					else{
					System.out.println(str);
					bufferedWriter.write(str); //Escribir la cadena
					bufferedWriter.flush(); //Escribir en el archivo
					}
					
				}
			bufferedWriter.flush(); //Escribir en el archivo
			}
		}
		catch(Exception exc) {
			System.out.println(exc.getMessage());
		}
	}
}