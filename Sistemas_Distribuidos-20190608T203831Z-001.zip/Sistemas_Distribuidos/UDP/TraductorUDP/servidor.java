import java.net.*;
import java.io.*;

public class servidor {
    public static void main(String args[]) {
	try {
            DatagramSocket s = new DatagramSocket(6789);
            byte [] bu = new byte[1024];
            int  a = 0;
            while(true) {
		while(a == 0){
                    DatagramPacket dp = new DatagramPacket(bu, bu.length);
                    s.receive(dp);
                    TR t = new TR(dp, s);
                 }
             }
          }
          catch(Exception exc) {
              System.out.println(exc.getMessage());
          }
     }
}

class TR{
    public TR(DatagramPacket dt, DatagramSocket ss){
       try{
           DatagramSocket s = ss; //Le asignamos al DatagramSocket creado en esta clase el recibido como parametro
           DatagramPacket dp = dt; //Le asignamos al DatagramPacket creado en esta clase el recibido como parametro
           int found = 0; //Variable que determinara si la palabra ingresada por el usuario se encuentra en el fichero
           int indice = 0; //Variable que almacenara la posicion en el array de la palabra encontrada
           FileInputStream inputStream = new FileInputStream("Traducciones.txt");
           byte [] m = new byte[1024];
           String palabra = new String(dp.getData());
           palabra+="\0"; //Eliminamos los archivos basura
           palabra.trim(); //que puede contener el string
           String [] prueba = palabra.split("="); //Separamos la palabra y el tipo de traduccion que desea hacer el cliente
           int nRead = 0;
           String convert;
           convert = new String(m);
           //Leemos el fichero
           while ((nRead = inputStream.read(m)) != -1) {
                convert = new String(m); //Convertimos los datos del fichero a String
           } 
           String [] aux = convert.split("="); //Separamos las palabras en ingles y español
           if(prueba[1].contains("0")){ //Verificamos si el usuario desea hacer una traduccion de ingles a español
               for(int i=0; i<aux.length; i=i+2){ //Los indices pares contienen las palabras en ingles
                    if(prueba[0].equals(aux[i])){ //Si la palabra enviada por el usuario es correcta
                        found = 1; //Ponemos found a verdadero
                        indice = i; //Obtenemos la posicion donde esta ubicada la palabra
                        break; //Terminamos el ciclo porque ya encontramos la palabra
                    }
                }
                if(found == 1){
                     byte [] envio = aux[indice+1].getBytes(); //Enviamos indice+1 porque indice contiene la palabra en ingles e indice+1 la traduccion
                     DatagramPacket t = new DatagramPacket(envio, envio.length, dp.getAddress(), dp.getPort());
                     ss.send(t);
                }
                else{ //Si la palabra no fue encontrada, mandamos un error
                     String error = "Error: Palabra solicitada no existe";
                     byte [] er = error.getBytes();
                     DatagramPacket q = new DatagramPacket(er, er.length, dp.getAddress(), dp.getPort());
                     ss.send(q);
                }  
           }
           else{ //Si el usuario desea una traduccion de español a ingles
                for(int i=1; i<aux.length; i=i+2){ //Los indices impares contienen las palabras en ingles
                    if(prueba[0].equals(aux[i])){
                        found = 1;
                        indice = i;
                        break;
                    }
                }
                if(found == 1){
                     byte [] envio = aux[indice-1].getBytes(); //Convertimos la traduccion a bytes
                     DatagramPacket t = new DatagramPacket(envio, envio.length, dp.getAddress(), dp.getPort());
                     ss.send(t); //Enviamos la traduccion
                }
                else{
                     String error = "Error: Palabra solicitada no existe";
                     byte [] er = error.getBytes();
                     DatagramPacket q = new DatagramPacket(er, er.length, dp.getAddress(), dp.getPort());
                     ss.send(q); //Enviamos un msj de error
                }  
           }
           
       }catch(IOException e){System.out.println(e.getMessage());}
    }
}