En el servidor, le cambie el nombre a la clase dataRT a RT porque con dataRT me daba un error.
En la clase RT no utilice las variables int tipo porque al realizar la conversion de tring a entero me daba error.
Referente a las bibliografias, no utilice otras ademas de las brindadas por el docente, la solucion a la practica la invente yo, apoyandome en las practicas anteriores.