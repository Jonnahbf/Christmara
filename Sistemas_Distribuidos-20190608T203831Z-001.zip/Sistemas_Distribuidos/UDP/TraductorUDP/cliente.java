import java.net.*;
import java.io.*;
import java.util.Scanner;

public class cliente {
    public static void main(String args[]) {
	try {
            Scanner leer = new Scanner( System.in ); //Objeto de tipo Scanner que ocupamos para leer el tipo de traduccion
            Scanner read = new Scanner(System.in); //Objeto de tipo Scanner que ocupamos para leer las palabras a traducir
            int dato; //Variable que almacenara el tipo de traduccion
            int a = 1; //Variable ocupada para realizar el ciclo
            String palabra; //variable que almacenara la palabra ingresada por el usuario
            dataTR data; 
            while(a == 1){
                System.out.println("1. Ingles a Español");
                System.out.println("2. Español a Ingles");
                System.out.println("3. Salir");
                dato = leer.nextInt();
                switch(dato){
                    case 1:
                       System.out.println("Ingrese la palabra: ");
                       palabra = read.nextLine();
                       data = new dataTR(palabra, 0); //Le pasamos la palabra y 0 para indicar el tipo de traduccion
                       break;
                    case 2:
                       System.out.println("Ingrese la palabra: ");
                       palabra = read.nextLine();
                       data = new dataTR(palabra, 1); //Le pasamos la palabra y 0 para indicar el tipo de traduccion
                       break;
                    case 3:
                        a = 0;
                        System.out.println("Cerrando aplicacion"); //En caso de que el usuario desee salir
                        data = new dataTR("Salir", 3);
                        break; 
                    default:
                        System.out.println("Opcion incorrecta, intente de nuevo");
                        break;
                }
            }
	}
	catch(Exception exc) {
            System.out.println(exc.getMessage());
	}
    }
}

class dataTR{
    public dataTR(String dato, int num){
       try{
            DatagramSocket s = new DatagramSocket();
            InetAddress h = InetAddress.getByName("localhost");
            int puerto = 6789;
            DatagramPacket t;
            if(num == 3){ //Si el usuario desea salir, cerramos la conexion
                s.close();
            }
            else{ //Si el usuario desea realizar traducciones
                byte[] m = new byte[1024];
                int tipo = num; 
                String palabra = dato;
                palabra = palabra+"="+tipo; //Concatenamos la palabra con el tipo de traduccion para que el server sepa la traduccion que queremos hacer
                m = palabra.getBytes(); //Convertimos el string a bytes
                t = new DatagramPacket(m, m.length, h, puerto); //Le asignamos los bytes, el puerto y la direccion
                s.send(t); //Enviamos el Datagrama
                byte [] receive = new byte[1024]; //Variable que almacenara la respuesta que nos mande el server
                DatagramPacket dt = new DatagramPacket(receive, receive.length);
                s.receive(dt);
                System.out.println(new String(dt.getData())); //Imprimimos la respuesta
            }
            
       }catch(IOException e){System.out.println(e.getMessage());}
    }
}