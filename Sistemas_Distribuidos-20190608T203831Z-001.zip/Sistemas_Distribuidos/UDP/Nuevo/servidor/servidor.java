import java.net.*;
import java.io.*;

public class servidor {
	public static void main(String args[]) {
		try {
			DatagramSocket s = new DatagramSocket(6789);
			byte [] bu = new byte[1024];
			while(true) {
				DatagramPacket p = new DatagramPacket(bu, bu.length);
				s.receive(p);
				
				Thread.sleep(60000);

				DatagramPacket r = new DatagramPacket(p.getData(), p.getLength(), p.getAddress(), p.getPort());
				s.send(r);
			}
		}
		catch(Exception exc) {
			System.out.println(exc.getMessage());
		}
	}
}