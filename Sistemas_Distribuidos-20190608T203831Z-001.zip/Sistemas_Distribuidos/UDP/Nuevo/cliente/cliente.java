import java.net.*;
import java.io.*;

public class cliente {
	public static void main(String args[]) {
		try {
			DatagramSocket s = new DatagramSocket();
			byte [] m = args[0].getBytes();
			InetAddress h = InetAddress.getByName(args[1]);
			int puerto = 6789;
			DatagramPacket p = new DatagramPacket(m, args[0].length(), h, puerto);
			s.send(p);
			
			byte [] recv = new byte[1024];
			DatagramPacket r = new DatagramPacket(recv, recv.length);
			s.receive(r);
			System.out.println(new String(r.getData()));
			s.close();
		}
		catch(Exception exc) {
			System.out.println(exc.getMessage());
		}
	}
}