import java.rmi.*;


public interface Interfaz extends Remote{

	public int calcularEdad(int m) throws RemoteException;
}