import java.net .*;
import java.io.*;
import java.util.Scanner;

public class ClienteTCP{
	public static void main(String args[]){

		try{
			int puerto = 5003;
			Socket s = new Socket(args[0], puerto); //Ip destino y puerto Destino

			Scanner leer = new Scanner( System.in ); //Objeto de tipo Scanner que ocupamos para leer los datos que ingresa el usuario
			String name;

			System.out.println("Ingrese el nombre del archivo que desea descargar: ");
			name = leer.nextLine(); //Guardamos el nombre del archivo que el cliente quiere descargar

			//Envia informacion
			DataOutputStream salida = new DataOutputStream(s.getOutputStream());
			salida.writeUTF(name);

			DataInputStream entrada = new DataInputStream(s.getInputStream());
			String datos = entrada.readUTF();

			//Si el servidor nos dice que encontro el archivo
			if(datos.equals("si")){ //Procedemos a descargar el archivo
				String a = "recibidos/";
				String b = a + name;
				byte[] contents = new byte[10000];
				FileOutputStream fos = new FileOutputStream(b);
				BufferedOutputStream bos = new BufferedOutputStream(fos);
				InputStream is = s.getInputStream();
				//No of bytes read in one read() call
				int bytesRead = 0;
				while((bytesRead=is.read(contents))!=-1)
				bos.write(contents, 0, bytesRead);
				bos.flush();
				System.out.println("Archivo recibido con exito");
			}
			//Si el archivo solicitado no existe en el servidor
			else{
				System.out.println("Error al intentar descargar el archivo");
			}
		
			s.close();

		}catch(Exception e){
			System.out.println("Socket: "+e.getMessage());
		}
		
	}
}