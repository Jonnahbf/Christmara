import java.net.*;
import java.io.*;
import static java.util.concurrent.TimeUnit.NANOSECONDS;

public class servidor {
	public static void main(String args[]) {
		try {
			int puertoServicio = 5003;
			ServerSocket escuchandoSocket = new ServerSocket(puertoServicio);
			while(true) {
				Socket socketCliente = escuchandoSocket.accept();
				Conexion c = new Conexion(socketCliente);
			}
			}
			catch(Exception exc) {
				System.out.println(exc.getMessage());
			}
		}
}
		class Conexion extends Thread {
			DataInputStream entrada;
			DataOutputStream salida;
			Socket socketCliente;
	
			public Conexion(Socket unSocketCliente) {
				try {
					socketCliente = unSocketCliente;
					entrada = new DataInputStream(socketCliente.getInputStream());
					salida = new DataOutputStream(socketCliente.getOutputStream());
					this.start();
				}
				catch(Exception exc) {
					System.out.println(exc.getMessage());
				}
			}
			public void run() {
				try {
					int a;
					String datos = entrada.readUTF();
		
					a = busqueda(datos); //Mandamos a llamar al metodo que se encarga de buscar si el archivo solicitado por el cliente existe o no.
				
					 //Si el metodo devuelve 1 quiere decir que el archivo si existe
					if(a==1) {
						salida.writeUTF("si");
						String ac = "archivos/";
						String b = ac+datos;
						File file = new File(b);
						FileInputStream fis = new FileInputStream(file);
						BufferedInputStream bis = new BufferedInputStream(fis);
				
						OutputStream os = socketCliente.getOutputStream();
						//Read File Contents into contents array
						byte[] contents;
						long fileLength = file.length();
						long current = 0;
						long start = System.nanoTime();
						while(current!=fileLength){
							int size = 10000;
							if(fileLength - current >= size)
								current += size;
							else{
								size = (int)(fileLength - current);
								current = fileLength;
							}
							contents = new byte[size];
							bis.read(contents, 0, size);
							os.write(contents);
							System.out.println("Sending file ... "+(current*100)/fileLength+"% completed!");
						}
						os.flush();
					}
			
					//De lo contrario, mostramos un mensaje diciendo que el archivo no existe
					else {
						salida.writeUTF("no");
						System.out.println("El archivo solicitado no existe");
						
					}
					socketCliente.close();
				}
				catch(Exception exc) {
					System.out.println(exc.getMessage());
					}
			}

			public static int busqueda(String archivo){
					String files;
			
					//Creamos un archivo file y le pasamos la direccion de donde buscara los archivos solicitados por los clientes
					File file = new File("archivos");
			
					//Creamos un array de archivos para almacenar todos los archivos existentes en la carpeta especifica
					File[] list = file.listFiles();
			
					//Hacemos un for para recorrer todos los archivos que se encuentran en la carpeta
					for(int i=0; i<list.length; i++){
						if(list[i].isFile()){
							files =list[i].getName();
			
							//Comparamos los archivos existentes con el que el cliente desea descargar
							if(archivo.equals(files)){
			
								//Si el archivo existe retornamos 1 y terminamos el metodo porque ya encontramos el archivo que el cliente desea
								return 1;
							}
						}
					}
					
					//Si no se encuentra el archivo que el cliente desea, retornamos 0
					return 0;
			}


	}