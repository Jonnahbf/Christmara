import java.net.*;
import java.io.*;
import static java.util.concurrent.TimeUnit.NANOSECONDS;

public class ServidorTCP {
	public static void main(String args[]) {
		try {
			int puertoServicio = 7896;
			ServerSocket escuchandoSocket = new ServerSocket(puertoServicio);
			while(true) {
				Socket socketCliente = escuchandoSocket.accept();
				Conexion c = new Conexion(socketCliente);
			}
			}
			catch(Exception exc) {
				System.out.println(exc.getMessage());
			}
		}
}
		class Conexion extends Thread {
			DataInputStream entrada;
			DataOutputStream salida;
			Socket socketCliente;
	
			public Conexion(Socket unSocketCliente) {
				try {
					socketCliente = unSocketCliente;
					entrada = new DataInputStream(socketCliente.getInputStream());
					salida = new DataOutputStream(socketCliente.getOutputStream());
					this.start();
				}
				catch(Exception exc) {
					System.out.println(exc.getMessage());
				}
			}
			public void run() {
				try {
					String datos = entrada.readUTF();
					long startTime = System.nanoTime();
					StringBuffer sb = new StringBuffer(datos);
					sb =sb.reverse();
					String palabra = sb.toString();
					int a = 0;
					int b=0;
					int c =0;
					for (int i=0; i<palabra.length(); i++){
						a = i;
						if((palabra.charAt(i) == 'a')|| (palabra.charAt(i) == 'e') || (palabra.charAt(i) == 'i') || (palabra.charAt(i) == 'o') || (palabra.charAt(i) == 'u')){
							b++;
						}
						else{
							if(Character.isLetter(palabra.charAt(i)))
								c++;
						}
					}
					a = a+1;
					palabra = palabra + "*" + a+"*"+b+"*"+c;
					salida.writeUTF(palabra);
					long endTime = System.nanoTime() - startTime;
					long nano = 0;
					nano = nano + endTime;
					System.out.println("El tiempo que tarda en ejecutarse el programa es: " + nano + " nanosegundos");
					socketCliente.close();
				}
				catch(Exception exc) {
					System.out.println(exc.getMessage());
					}
			}
		}