import java.net.*;
import java.io.*;
import java.util.Scanner;

public class ClienteTCP {
	public static void main(String args[]) {
		try {
			int puertoServicio = 7896;
			Socket s = new Socket(args[0], puertoServicio);
			DataInputStream entrada = new DataInputStream(s.getInputStream());
			DataOutputStream salida = new DataOutputStream(s.getOutputStream());
			String cadena;
			salida.writeUTF(args[1]);
			cadena = entrada.readUTF();
			System.out.println(cadena);
			s.close();
		}			
		catch(Exception exc) {
			System.out.println(exc.getMessage());
		}
	}
}
