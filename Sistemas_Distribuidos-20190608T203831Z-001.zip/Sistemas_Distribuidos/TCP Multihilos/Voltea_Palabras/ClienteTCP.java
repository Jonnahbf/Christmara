import java.net.*;
import java.io.*;
import java.util.Scanner;

public class ClienteTCP {
	public static void main(String args[]) {
		try {
			int puertoServicio = 7896;
			Socket s = new Socket(args[0], puertoServicio);
			DataInputStream entrada = new DataInputStream(s.getInputStream());
			DataOutputStream salida = new DataOutputStream(s.getOutputStream());
			Scanner datos = new Scanner(System.in);
			System.out.println("Ingrese la cadena");
			String cadena = datos.nextLine();
			salida.writeUTF(cadena);
			cadena = entrada.readUTF();
			System.out.println(cadena);
			s.close();
		}			
		catch(Exception exc) {
			System.out.println(exc.getMessage());
		}
	}
}
