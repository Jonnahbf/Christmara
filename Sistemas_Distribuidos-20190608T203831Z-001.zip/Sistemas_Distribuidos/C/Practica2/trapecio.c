#include <stdio.h>
#include<math.h>

float Perimetro(float, float, float, float);
float Altura(float, float, float, float);
float Area(float, float, float);

int main(){
	float a, b, c, d;
	float area, altura, perimetro;
	printf("Ingrese la base mayor del perimetro ");
	scanf("%f", &a);
	do{
		printf("Ingrese la base menor del perimetro ");
		scanf("%f", &c);
		if(c>a)
			printf("Debe ingresar un valor menor que la base mayor\n");
	}while(c > a);
	
	printf("Ingrese los lados paralelos del perimetro ");
	scanf("%f", &b);
	printf("Ingrese los lados paralelos del perimetro ");
	scanf("%f", &d);

	perimetro = Perimetro(a,b,c,d);
	altura = Altura(a,c,b,d);

	if(altura>0){
		area = Area(altura, a, c);
		printf("La altura del trapecio es: %f\n", altura);
		printf("El area del trapecio es: %f\n", area);
	 }
	else{
		printf("Error al calcular altura de trapecio por datos ingresados erroneos\n");
		printf("Error al calcular area de trapecio por datos ingresados erroneos\n");
	}
	printf("El perimetro del trapecio es: %f\n", perimetro);
	
	return 0;
}

float Perimetro(float a, float b, float c, float d){
	float result;
	result = a+b+c+d;
	return result;
}

float Altura(float a, float c, float b, float d){
	float result;
	float ac, d2, b2, result1, ad2, a1;
	ac = (a-c)*(a-c);
	d2 = d*d;
	b2 = b*b;
	a1 = a-c;
	result1 = 4 * ac * d2;
	ad2 = pow((d2 + ac - b2), 2);
	if(ad2 > result1)
		result = 0.0;
	else{
		result = result1 - ad2;
		result = (sqrt(result)) / (2*a1);
	}
	return result;
}

float Area(float altura, float a, float c){
	float result;
	result = altura * (a+c);
	result = result / 2;
	return result;
}