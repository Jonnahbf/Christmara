/*holas.c - Servidor*/

#include <stdio.h>
#include <rpc/rpc.h>
#include "hola.h"

char **str_hola_1_svc(void *a, struct svc_req *b) {
	static char *ptr;
	ptr = "Hola mundo!!!";
	return (&ptr);
}